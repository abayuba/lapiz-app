Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_lapiz-app-de_DE.po
* app_lapiz-app-id_ID.po
* app_lapiz-app_ES.po
* app_lapiz-app-en_US.po
* app_lapiz-app-de_DE.mo
* app_lapiz-app-id_ID.mo
* app_lapiz-app-es_ES.mo
* app_lapiz-app-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
